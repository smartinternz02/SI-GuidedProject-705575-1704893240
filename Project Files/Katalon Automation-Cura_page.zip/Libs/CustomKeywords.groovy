
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "cura_custom_keyword_001.verifyElementClickable.isElementClickable"(
    	TestObject tb	) {
    (new cura_custom_keyword_001.verifyElementClickable()).isElementClickable(
        	tb)
}


def static "cura_custom_keyword_001.Check_DropDown.check_drop_downlistexits"(
    	TestObject object	
     , 	String option	) {
    (new cura_custom_keyword_001.Check_DropDown()).check_drop_downlistexits(
        	object
         , 	option)
}
